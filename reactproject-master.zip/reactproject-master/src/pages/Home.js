// src/pages/Home.js
import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Supermarket Management System</h1>
    </div>
  );
};

export default Home;